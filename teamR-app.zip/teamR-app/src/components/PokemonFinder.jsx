import React, { useState, useEffect } from 'react'
import './PokemonFinder.css'

const PokemonFinder = () => {
  const [search, setSearch] = useState('')
  const [suggestions, setSuggestions] = useState([])
  const [allPokemon, setAllPokemon] = useState([])
  const [selectedPokemon, setSelectedPokemon] = useState(null)
  const [previousPokemon, setPreviousPokemon] = useState(null)
  const [nextPokemon, setNextPokemon] = useState(null)

  useEffect(() => {
    fetch('https://pokeapi.co/api/v2/pokemon?limit=1000')
      .then(response => response.json())
      .then(data => {
        setAllPokemon(data.results)
      })
  }, [])

  const handleInputChange = (e) => {
    const value = e.target.value
    setSearch(value)
    if (value.length > 0) {
      const filteredSuggestions = allPokemon.filter(pokemon =>
        pokemon.name.toLowerCase().includes(value.toLowerCase())
      )
      setSuggestions(filteredSuggestions)
    } else {
      setSuggestions([])
    }
  }

  const handleSuggestionClick = (pokemon) => {
    fetchPokemon(pokemon.name)
    setSearch('')
    setSuggestions([])
  }

  const fetchPokemon = (nameOrId) => {
    fetch(`https://pokeapi.co/api/v2/pokemon/${nameOrId}`)
      .then(response => response.json())
      .then(data => {
        setSelectedPokemon(data)
        if (data.id > 1) {
          fetch(`https://pokeapi.co/api/v2/pokemon/${data.id - 1}`)
            .then(response => response.json())
            .then(prevData => setPreviousPokemon(prevData))
        } else {
          setPreviousPokemon(null)
        }
        if (data.id < 1302) {
          fetch(`https://pokeapi.co/api/v2/pokemon/${data.id + 1}`)
            .then(response => response.json())
            .then(nextData => setNextPokemon(nextData))
        } else {
          setNextPokemon(null)
        }
      })
  }

  const handleNext = () => {
    if (nextPokemon) {
      fetchPokemon(nextPokemon.id)
    }
  }

  const handlePrevious = () => {
    if (previousPokemon) {
      fetchPokemon(previousPokemon.id)
    }
  }

  return (
    <div className={`pokemon-finder`}>
      <header>
        <h1>we didn't catch'em all</h1>
      </header>
      <div className="search-container">
        <input
          type="text"
          placeholder="Name a Pokémon"
          value={search}
          onChange={handleInputChange}
        />
        {suggestions.length > 0 && (
          <ul className="suggestions-list">
            {suggestions.map((pokemon, index) => (
              <li key={index} onClick={() => handleSuggestionClick(pokemon)}>
                {pokemon.name}
              </li>
            ))}
          </ul>
        )}
      </div>
      {selectedPokemon && suggestions.length === 0 && (
        <div className="pokemon-details">
            <div className="current-pokemon">
            <h2>{selectedPokemon.name}</h2>
            <p>{selectedPokemon.id}</p>
            <img src={selectedPokemon.sprites.front_default} alt={selectedPokemon.name} />
          </div>
          <div className="navigation-buttons">
            {previousPokemon && (
              <div className="prev-pokemon" onClick={handlePrevious}>
                <button className="arrow-button">&lt;</button>
                <img src={previousPokemon.sprites.front_default} alt="Previous" />
                
              </div>
            )}
            {nextPokemon && (
              <div className="next-pokemon" onClick={handleNext}>
                <img src={nextPokemon.sprites.front_default} alt="Next" />
                <button className="arrow-button">&gt;</button>
              </div>
            )}
          </div>
          
        </div>
      )}
    </div>
  )
}

export default PokemonFinder
