# TEAMR-APP

I tried to make an app where a user can search for all the Pokémon that Team Rocket didn't catch.
Obviously, I failed with the CSS side of the app, but given the suggested time, I focused on the usability, making sure the component was working properly.


